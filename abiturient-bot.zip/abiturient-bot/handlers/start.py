from aiogram import Router
from aiogram.filters import CommandStart
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

from database.db import upsert_user

router = Router()

MAIN_MENU = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="📊 Мои шансы на поступление", callback_data="calc")],
    [InlineKeyboardButton(text="⚖️ Сравнить два вуза", callback_data="compare")],
    [InlineKeyboardButton(text="🎯 Подобрать вуз под меня", callback_data="recommend")],
])


@router.message(CommandStart())
async def cmd_start(message: Message):
    upsert_user(message.from_user.id, message.from_user.username)
    await message.answer(
        "Привет! Я помогу разобраться с поступлением:\n\n"
        "— посчитаю шансы по твоим баллам\n"
        "— сравню два вуза по ключевым критериям\n"
        "— подберу вуз под твои пожелания\n\n"
        "Выбери, с чего начать 👇",
        reply_markup=MAIN_MENU,
    )
