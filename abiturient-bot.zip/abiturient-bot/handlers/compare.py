import json
from aiogram import Router, F
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message
from services.ai_client import compare_universities
from database.db import save_comparison

router = Router()


class CompareStates(StatesGroup):
    waiting_for_vuz1 = State()
    waiting_for_vuz2 = State()


@router.callback_query(F.data == "compare")
async def start_compare(callback: CallbackQuery, state: FSMContext):
    await callback.message.answer("Название первого вуза/программы?")
    await state.set_state(CompareStates.waiting_for_vuz1)
    await callback.answer()


@router.message(CompareStates.waiting_for_vuz1)
async def get_vuz1(message: Message, state: FSMContext):
    await state.update_data(vuz1=message.text)
    await message.answer("А теперь второй вуз/программа?")
    await state.set_state(CompareStates.waiting_for_vuz2)


@router.message(CompareStates.waiting_for_vuz2)
async def get_vuz2(message: Message, state: FSMContext):
    data = await state.get_data()
    vuz1, vuz2 = data["vuz1"], message.text

    thinking = await message.answer("Сравниваю... ⏳")
    result = await compare_universities(vuz1, vuz2)

    if result is None:
        await thinking.edit_text("Не получилось получить сравнение — попробуй ещё раз чуть позже.")
        await state.clear()
        return

    await thinking.edit_text(format_table(vuz1, vuz2, result))
    save_comparison(message.from_user.id, vuz1, vuz2, json.dumps(result, ensure_ascii=False))
    await state.clear()


def format_table(vuz1: str, vuz2: str, rows: list[dict]) -> str:
    lines = [f"<b>{vuz1}</b> vs <b>{vuz2}</b>\n"]
    for row in rows:
        lines.append(
            f"<b>{row['criterion']}</b>\n"
            f"  {vuz1[:25]}: {row['vuz1']}\n"
            f"  {vuz2[:25]}: {row['vuz2']}"
        )
    return "\n\n".join(lines)
