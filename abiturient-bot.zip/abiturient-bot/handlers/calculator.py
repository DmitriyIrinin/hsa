from aiogram import Router, F
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

from services.ai_client import estimate_chances
from services.matcher import calculate_chances as calculate_chances_fallback

router = Router()


class CalcStates(StatesGroup):
    waiting_for_field = State()
    waiting_for_score = State()


@router.callback_query(F.data == "calc")
async def start_calc(callback: CallbackQuery, state: FSMContext):
    await callback.message.answer("Какое направление интересует? (например: ИТ/математика)")
    await state.set_state(CalcStates.waiting_for_field)
    await callback.answer()


@router.message(CalcStates.waiting_for_field)
async def get_field(message: Message, state: FSMContext):
    await state.update_data(field=message.text)
    await message.answer("Сколько баллов ЕГЭ суммарно?")
    await state.set_state(CalcStates.waiting_for_score)


@router.message(CalcStates.waiting_for_score)
async def get_score(message: Message, state: FSMContext):
    if not message.text.isdigit():
        await message.answer("Введи число, например 270")
        return

    data = await state.get_data()
    score = int(message.text)
    field = data.get("field")

    thinking = await message.answer("Ищу подходящие варианты... ⏳")
    results = await estimate_chances(field, score)
    used_fallback = False

    if not results:
        used_fallback = True
        raw_fallback = calculate_chances_fallback(score, field)
        results = [
            {
                "vuz": r["vuz"],
                "program": r["program"],
                "city": r.get("city", ""),
                "passing_score_approx": str(r["passing_score_2025"]),
                "chance": r["chance"],
            }
            for r in raw_fallback
        ]

    if not results:
        await thinking.edit_text("Не нашёл направлений по такому запросу — попробуй сформулировать иначе.")
        await state.clear()
        return

    lines = []
    if used_fallback:
        lines.append("⚠️ Не получилось спросить ИИ, показываю локальную подборку (она короче):\n")
    lines.append(f"По баллу {score} вот что нашлось:\n")
    for r in results[:7]:
        lines.append(
            f"🏫 {r['vuz']} — {r['program']} ({r.get('city', '')})\n"
            f"   Проходной ~{r['passing_score_approx']} — {r['chance']}\n"
        )
    await thinking.edit_text("\n".join(lines))
    await state.clear()
