import json

from aiogram import Router, F
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

from services.matcher import get_candidates as get_candidates_fallback
from services.ai_client import estimate_chances, recommend_university
from database.db import save_recommendation

router = Router()


class RecommendStates(StatesGroup):
    waiting_for_field = State()
    waiting_for_score = State()
    waiting_for_preferences = State()


@router.callback_query(F.data == "recommend")
async def start_recommend(callback: CallbackQuery, state: FSMContext):
    await callback.message.answer("Какое направление интересует?")
    await state.set_state(RecommendStates.waiting_for_field)
    await callback.answer()


@router.message(RecommendStates.waiting_for_field)
async def get_field(message: Message, state: FSMContext):
    await state.update_data(field=message.text)
    await message.answer("Баллы ЕГЭ суммарно?")
    await state.set_state(RecommendStates.waiting_for_score)


@router.message(RecommendStates.waiting_for_score)
async def get_score(message: Message, state: FSMContext):
    if not message.text.isdigit():
        await message.answer("Введи число")
        return
    await state.update_data(score=int(message.text))
    await message.answer("Есть доп. пожелания? (город, бюджет/платное, общежитие и т.п. — можно списком)")
    await state.set_state(RecommendStates.waiting_for_preferences)


@router.message(RecommendStates.waiting_for_preferences)
async def get_preferences(message: Message, state: FSMContext):
    data = await state.get_data()
    field, score, preferences = data["field"], data["score"], message.text

    candidates = await estimate_chances(field, score, preferences)
    if not candidates:
        candidates = get_candidates_fallback(field, score)
    if not candidates:
        await message.answer("Не нашёл подходящих вариантов по этим критериям.")
        await state.clear()
        return

    thinking = await message.answer("Подбираю лучший вариант... ⏳")
    result = await recommend_university(candidates, preferences)

    if result is None:
        await thinking.edit_text("Не получилось получить рекомендацию — попробуй ещё раз.")
        await state.clear()
        return

    await thinking.edit_text(
        f"🎯 <b>{result['vuz']}</b>\n{result['program']}\n\n{result['explanation']}"
    )
    save_recommendation(message.from_user.id, field, score, preferences, json.dumps(result, ensure_ascii=False))
    await state.clear()
