import json
import logging

from openai import AsyncOpenAI

from config import AI_API_KEY, AI_BASE_URL, AI_MODEL

logger = logging.getLogger(__name__)

client = AsyncOpenAI(api_key=AI_API_KEY, base_url=AI_BASE_URL)

COMPARE_SYSTEM_PROMPT = """Ты сравниваешь два направления подготовки в вузах по заданным критериям.
Верни СТРОГО валидный JSON-массив объектов вида:
{"criterion": string, "vuz1": string, "vuz2": string}
Без markdown, без текста до или после JSON.
Критерии обязательно: проходной балл, стоимость обучения в год, наличие общежития, срок обучения, топ отрасль трудоустройства выпускников.
Если точных данных нет — дай наиболее вероятную оценку с пометкой "~" перед значением."""

RECOMMEND_SYSTEM_PROMPT = """Тебе дан JSON-список подходящих вариантов (вуз, программа, проходной балл, город, стоимость).
Пользователь укажет дополнительные пожелания.
Выбери ОДИН вариант СТРОГО из переданного списка — не придумывай вузы и не добавляй варианты, которых нет в списке.
Верни JSON: {"vuz": string, "program": string, "explanation": string}
explanation — 2-4 предложения, почему этот вариант подходит лучше остальных с учётом пожеланий пользователя."""

CHANCES_SYSTEM_PROMPT = """Ты — эксперт по поступлению в российские вузы. Пользователь укажет направление подготовки, сумму баллов ЕГЭ (score) и, возможно, дополнительные пожелания (например, город).
Если пожелания указаны — ОБЯЗАТЕЛЬНО учитывай их при подборе: если просят конкретный город, предлагай вузы ИМЕННО в этом городе (или ближайшем крупном городе региона, если в самом городе по направлению вузов нет — тогда явно об этом скажи в поле "city").
Подбери 5-7 РЕАЛЬНО существующих российских вузов и программ по этому направлению (не выдумывай названия), проходной балл которых РЕАЛИСТИЧЕН именно для этого score:
- 2-3 варианта с проходным баллом близко к score (±15) — самые вероятные
- 1-2 варианта с проходным баллом заметно НИЖЕ score (минимум на 15-20) — подстраховка, куда пользователь пройдёт почти наверняка
- максимум 1 вариант с проходным баллом выше score, но не более чем на 15-20 баллов — вариант "на грани"
НЕ включай вузы, где проходной балл более чем на 20 баллов выше score пользователя — это бесполезная информация, пользователь туда не пройдёт.
Оценка "chance" должна строго соответствовать разнице score и проходного балла: score >= проходной → "высокие шансы"; score ниже на 1-10 → "есть шансы"; score ниже на 10-20 → "рискованно"; ниже сильнее — такой вуз вообще не включай в список.
Верни СТРОГО валидный JSON-массив объектов вида:
{"vuz": string, "program": string, "city": string, "passing_score_approx": string, "chance": string}
Без markdown, без текста до или после JSON."""


async def _ask_json(system_prompt: str, user_prompt: str):
    raw = None
    try:
        response = await client.chat.completions.create(
            model=AI_MODEL,
            messages=[ {"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt},],
            temperature=0.3,)
        raw = response.choices[0].message.content.strip()


        if raw.startswith("```"):
            raw = raw.strip("`")
            if raw.lower().startswith("json"):
                raw = raw.split("\n", 1)[-1]

        return json.loads(raw)
    except json.JSONDecodeError:
        logger.warning("AI вернул невалидный JSON: %s", raw)
        return None
    except Exception:
        logger.exception("Ошибка запроса к AI API")
        return None


async def compare_universities(vuz1: str, vuz2: str) -> list[dict] | None:
    user_prompt = f"Вуз 1: {vuz1}\nВуз 2: {vuz2}"
    result = await _ask_json(COMPARE_SYSTEM_PROMPT, user_prompt)
    return result if isinstance(result, list) else None


async def recommend_university(candidates: list[dict], preferences: str) -> dict | None:
    user_prompt = (
        f"Список вариантов:\n{json.dumps(candidates, ensure_ascii=False)}\n\n"
        f"Пожелания пользователя: {preferences}"
    )
    result = await _ask_json(RECOMMEND_SYSTEM_PROMPT, user_prompt)
    return result if isinstance(result, dict) else None


async def estimate_chances(field: str, score: int, preferences: str | None = None) -> list[dict] | None:
    user_prompt = f"Направление: {field}\nБаллы ЕГЭ: {score}"
    if preferences:
        user_prompt += f"\nДополнительные пожелания: {preferences}"
    result = await _ask_json(CHANCES_SYSTEM_PROMPT, user_prompt)
    if not isinstance(result, list):
        return None
    return _filter_realistic(result, score)


def _parse_score(value) -> int | None:
    try:
        return int(str(value).replace("~", "").strip())
    except (ValueError, TypeError):
        return None


def _filter_realistic(results: list[dict], score: int, max_gap: int = 20) -> list[dict]:
    filtered = []
    for r in results:
        p = _parse_score(r.get("passing_score_approx"))
        if p is None or p - score <= max_gap:
            filtered.append(r)

    if filtered:
        return filtered

    return sorted(
        results,
        key=lambda r: abs((_parse_score(r.get("passing_score_approx")) or score) - score),
    )[:5]
