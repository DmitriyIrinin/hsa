import json
from pathlib import Path

DATA_PATH = Path(__file__).resolve().parent.parent / "data" / "universities.json"


def load_universities() -> list[dict]:
    with open(DATA_PATH, encoding="utf-8") as f:
        return json.load(f)


def calculate_chances(score: int, field: str | None = None) -> list[dict]:
    unis = load_universities()
    if field:
        field_lower = field.lower()
        unis = [u for u in unis if field_lower in u["field"].lower()]

    results = []
    for u in unis:
        diff = score - u["passing_score_2025"]
        if diff >= 10:
            chance = "Высокие шансы"
        elif diff >= 0:
            chance = "Есть шансы, но без запаса"
        elif diff >= -10:
            chance = "Скорее не хватит, но подавай — бывают колебания"
        else:
            chance = "Маловероятно на бюджет"
        results.append({**u, "diff": diff, "chance": chance})

    results.sort(key=lambda x: x["diff"], reverse=True)
    return results


def get_candidates(field: str, score: int, top_n: int = 5) -> list[dict]:
    return calculate_chances(score, field)[:top_n]


def find_university(name: str) -> dict | None:
    name_lower = name.lower()
    for u in load_universities():
        if name_lower in u["vuz"].lower():
            return u
    return None
