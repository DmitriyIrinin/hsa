import sqlite3
from contextlib import contextmanager

from config import DB_PATH


@contextmanager
def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()


def init_db():
    with get_conn() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                telegram_id INTEGER PRIMARY KEY,
                username TEXT,
                ege_score INTEGER,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS comparisons (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                telegram_id INTEGER,
                vuz1 TEXT,
                vuz2 TEXT,
                result_json TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS recommendations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                telegram_id INTEGER,
                direction TEXT,
                score INTEGER,
                preferences TEXT,
                result_json TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()


def upsert_user(telegram_id: int, username: str | None, ege_score: int | None = None):
    with get_conn() as conn:
        conn.execute("""
            INSERT INTO users (telegram_id, username, ege_score)
            VALUES (?, ?, ?)
            ON CONFLICT(telegram_id) DO UPDATE SET
                username = excluded.username,
                ege_score = COALESCE(excluded.ege_score, users.ege_score)
        """, (telegram_id, username, ege_score))
        conn.commit()


def save_comparison(telegram_id: int, vuz1: str, vuz2: str, result_json: str):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO comparisons (telegram_id, vuz1, vuz2, result_json) VALUES (?, ?, ?, ?)",
            (telegram_id, vuz1, vuz2, result_json),
        )
        conn.commit()


def save_recommendation(telegram_id: int, direction: str, score: int, preferences: str, result_json: str):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO recommendations (telegram_id, direction, score, preferences, result_json) "
            "VALUES (?, ?, ?, ?, ?)",
            (telegram_id, direction, score, preferences, result_json),
        )
        conn.commit()
